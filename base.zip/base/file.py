def dividir(dividendo:float,divisor:float):
    return dividendo/divisor 

